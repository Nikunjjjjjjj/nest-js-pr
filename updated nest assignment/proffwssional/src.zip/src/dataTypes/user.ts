export const UserStatus = {
    PENDING: 0,
    ACTIVE: 1,
  };

  export const UserRole = {
    ADMIN: 0,
    USER: 1,
  };
// export const UserStatus = {
//     PENDING: 0,
//     ACTIVE: 1,
//   };

  export const UserRole = {
    ADMIN: "Admin",
    USER: "Student",
  };